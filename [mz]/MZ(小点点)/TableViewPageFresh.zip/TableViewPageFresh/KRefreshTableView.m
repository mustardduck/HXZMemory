//
//  KRefreshTableView.m
//  DragList
//
//  Created by Kevin on 12-12-28.
//  Copyright (c) 2012年 Kevin. All rights reserved.
//

#import "KRefreshTableView.h"

@implementation KRefreshTableView

- (id)initWithFrame:(CGRect)frame
{
    self = [super initWithFrame:frame];
    if (self) {
        // Initialization code
    }
    return self;
}



- (void)dealloc
{
    [self.MyDelegate release];
    [self.Items release];
    
    [super dealloc];
}

#pragma mark -- 处理下拉，上拉效果  －－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－－







//footer上拉处理线程结束会调用这个函数
- (void) FinishedLoadMoreFooterData: (NSNumber*) num
{
    [self reloadData];//重新装载数据
    //将滚动条定位到上拉前的那一条item
    NSLog(@"item coutn = %d" , [self.Items count]);
    NSMutableArray* ary = self.Items;//table绑定的数据源
    int prevNum = [ary count]  - num.intValue;//得到更新前的行数
    if (prevNum >= 1) {
        NSIndexPath* row = [NSIndexPath indexPathForRow:prevNum - 1 inSection:0];
        //将table定位到更新时的位置
        [self scrollToRowAtIndexPath:row atScrollPosition:UITableViewScrollPositionNone animated:NO];
        
    }
    
    [num release];
    
}


//用户将footer往上拉的时候，放一些数据
- (void) GetMoreFooterData
{
    @autoreleasepool {
        int ret = [self.MyDelegate UpdateData:NO];//获取增加的行数
        NSNumber* number = [NSNumber numberWithInt:ret];
        [number retain];//主线程需要release
        
        [self performSelectorOnMainThread:@selector(FinishedLoadMoreFooterData:) withObject:number waitUntilDone:YES];
    }
}



- (void) InitTable: (id) TableItems
{
    self.Items = TableItems;
    
    headerview = [[MJRefreshHeaderView alloc] initWithScrollView:self];
    footerview = [[MJRefreshFooterView alloc] initWithScrollView:self];
    headerview.delegate = self;
    footerview.delegate = self;
}

#pragma mark 代理方法-进入刷新状态就会调用
- (void)refreshViewBeginRefreshing:(MJRefreshBaseView *)refreshView
{
    [self performSelector:@selector(doneWithView:) withObject:refreshView afterDelay:1];
}

- (void)doneWithView:(MJRefreshBaseView *)refreshView
{
//    // 刷新表格
//    [[DataEngine getInstance] setIsFirst:([refreshView isEqual:headerview] ? YES : NO)];
//    [[DataEngine getInstance] getShoppingAddress:[LoginManager sharedInstance].curUserId];
    //启动一个线程来获取更新数据
    if(footerview == refreshView)
    {
       // [NSThread detachNewThreadSelector:@selector(GetMoreFooterData) toTarget:self withObject:nil];
        [self.MyDelegate UpdateData:NO];
    }
    else
    {
        [self.MyDelegate UpdateData:YES];
    }
    
    [self reloadData];
    // (最好在刷新表格后调用)调用endRefreshing可以结束刷新状态
    [refreshView endRefreshing];
    
}


/*
// Only override drawRect: if you perform custom drawing.
// An empty implementation adversely affects performance during animation.
- (void)drawRect:(CGRect)rect
{
    // Drawing code
}
*/

@end
